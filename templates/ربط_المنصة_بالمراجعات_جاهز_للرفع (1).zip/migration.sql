-- 📚 المراجعات التفاعلية — جدولان جديدان فقط (لا تمس أي جدول موجود)
create table if not exists review_events (
  id bigserial primary key,
  type text not null, ts bigint not null,
  app text, unit int, title text, device text, student text,
  data jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);
create index if not exists review_events_dev on review_events(device);
create index if not exists review_events_app on review_events(app, unit, ts);

create table if not exists review_licenses (
  device text not null, scope text not null, code text not null,
  customer text, note text, active boolean default true,
  created_at timestamptz default now(),
  primary key (device, scope)
);

-- 🔒 الحماية: لا أحد يقرأ أو يكتب مباشرة بالمفتاح العام (anon)
-- السيرفر يصل إليها بمفتاح الخدمة SUPABASE_SERVICE_KEY الذي يتجاوز RLS
alter table review_events enable row level security;
alter table review_licenses enable row level security;

-- 🧠 مدير المنصة — جداول جديدة فقط
create table if not exists staff_users (
  id bigserial primary key,
  username text unique not null, pass_hash text not null, name text not null,
  perms text[] default '{}', active boolean default true,
  created_at timestamptz default now(), last_login timestamptz
);
create table if not exists content_jobs (
  id bigserial primary key,
  grade text not null, semester text, unit text, lesson text not null,
  n_req int default 15, n_made int default 0, n_verified int default 0,
  book_path text, pages text, status text default 'queued', log text,
  created_by text, created_at timestamptz default now(), finished_at timestamptz
);
create index if not exists content_jobs_status on content_jobs(status, id);
create table if not exists question_drafts (
  id bigserial primary key,
  job_id bigint, grade text, semester text, unit text, lesson text,
  q_type text, question text, options text, answer text, difficulty text,
  explanation text, check_answer text, verified boolean default false,
  status text default 'pending', reviewer text,
  created_at timestamptz default now()
);
create index if not exists question_drafts_q on question_drafts(status, grade, lesson);
create table if not exists manager_log (
  id bigserial primary key, ts timestamptz default now(),
  actor text, action text, detail text
);
alter table staff_users enable row level security;
alter table content_jobs enable row level security;
alter table question_drafts enable row level security;
alter table manager_log enable row level security;

-- 📦 مصنع الدرس
alter table question_drafts add column if not exists source text;
alter table question_drafts add column if not exists pack_id bigint;
create table if not exists lesson_packs (
  id bigserial primary key,
  grade text not null, semester text, unit text, lesson text not null,
  book_path text, book_pages text, act_path text, act_pages text, exams jsonb default '[]'::jsonb,
  n_questions int default 30, external_pct int default 15,
  n_questions_made int default 0, n_verified int default 0,
  summary jsonb, interactive_html text, pdf_html text,
  status text default 'queued', log text, created_by text, published_by text,
  created_at timestamptz default now(), finished_at timestamptz
);
alter table lesson_packs enable row level security;
